﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstanceARRMapping.Entity
{
   public class AppSettings
    {
        public string TenantID { get; set; }
        public string AADApplicationId { get; set; }
        public string AADApplicationKey { get; set; }
        public string SubscriptionId { get; set; }
    }
}
