﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InstanceARRMapping.Entity
{
    public class InstanceDetails
    {
        public string InstanceName { get; set; }
        public string ARRAffinityId { get; set; }
        public List<Process> ProcessList { get; set; }
    }

    public class Process
    {
        public string ProcessId { get; set; }
        public string ComputerName { get; set; }
    }


    
}
