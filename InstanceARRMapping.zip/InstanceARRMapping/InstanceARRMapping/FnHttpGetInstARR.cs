using System.Linq;
using System.Net;
using System.Net.Http;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using InstanceARRMapping.Lib;
using System.Threading.Tasks;
using InstanceARRMapping.Entity;

namespace InstanceARRMapping
{
    public static class FnHttpGetInstARR
    {
        [FunctionName("FnHttpGetInstARR")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", Route = "FnHttpGetInstARR/{ResourceGroup}/{WebAppName}")]HttpRequestMessage req, string WebAppName , string ResourceGroup, TraceWriter log)
        {
            /*
             * 
             * 
             # this will support get and url will look like 
            # ex : https://functionapparrmapper.azurewebsites.net/api/FnHttpGetInstARR/WebAppAnonomousAccess/WebAppAnonomousAccess
            # which is : https://<functionAppName>.azurewebsites.net/api/<HttpTrigger_C#_Function_Name>/{ResourceGroup_Name}/{WebAppName}
             * 
             * */
            log.Info("C# HTTP trigger function processed a request.");

            Library lib = new Library(ResourceGroup, WebAppName);
            var result=lib.GetADAccessToken();

            var InstaceList =await lib.GetInstaces();
            InstaceList = await lib.GetProcess_ForInstance();
            InstaceList = await lib.GetComputerName_ForInstance_FromProcess();

            // Fetching the name from the path parameter in the request URL
            var responce=InstaceList.Select(z=> new ResponceEntity { ARRAffinity = z.ARRAffinityId, Name = z.ProcessList.Where(y => y.ComputerName != "NA").FirstOrDefault().ComputerName });
            return req.CreateResponse(HttpStatusCode.OK, responce);
        }
    }
}
