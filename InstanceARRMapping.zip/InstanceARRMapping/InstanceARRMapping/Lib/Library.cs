﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using InstanceARRMapping.Entity;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Configuration;
using System.Net.Http;
using System.Web.Script.Serialization;

namespace InstanceARRMapping.Lib
{
   public class Library
    {
        public static AppSettings _appsettings = new AppSettings();
        string resourceGroup;
        string webAppName;
        TokenResponse accessToken;
        List<InstanceDetails> _ListInstance = null;

        static Library()
        {
            _appsettings.AADApplicationId = ConfigurationManager.AppSettings["AADApplicationId"].ToString();
            _appsettings.AADApplicationKey = ConfigurationManager.AppSettings["AADApplicationKey"].ToString();
            _appsettings.SubscriptionId = ConfigurationManager.AppSettings["SubscriptionId"].ToString();
            _appsettings.TenantID = ConfigurationManager.AppSettings["TenantID"].ToString();

        }

        public Library(string _resourceGroup, string _webAppName)
        {
            this.resourceGroup = _resourceGroup;
            this.webAppName = _webAppName;
            this.accessToken = GetADAccessToken().Result;
        }

        string instanceURL = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Web/sites/{2}/instances?api-version=2016-08-01";
        string ProcesListbyInstanceURL = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Web/sites/{2}/instances/{3}/processes?api-version=2015-08-01";
        string ProcessListbyProcessURL = "https://management.azure.com/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Web/sites/{2}/instances/{3}/processes/{4}?api-version=2015-08-01";
        public  async Task<TokenResponse> GetADAccessToken()
        {
            string tenantID = _appsettings.TenantID;
            string authContextURL = "https://login.microsoftonline.com/" + tenantID;
            string clientId = _appsettings.AADApplicationId;
            string clientSecret = _appsettings.AADApplicationKey;


            var authenticationContext = new AuthenticationContext(authContextURL);
            var credential = new ClientCredential(clientId: clientId, clientSecret: clientSecret);
            var result = await authenticationContext.AcquireTokenAsync(resource: "https://management.azure.com/", clientCredential: credential);

            if (result == null)
            {
                throw new InvalidOperationException("Failed to obtain the Azure Active Directive token");
            }


            var response = new TokenResponse() { AccessToken = result.AccessToken, TokenType = result.AccessTokenType };

            return response;
        }

        public  async Task<List<InstanceDetails>> GetInstaces()
        {

            List<InstanceDetails> _InstanceListTask = new List<InstanceDetails>();

            string endpoint = string.Format(instanceURL, _appsettings.SubscriptionId, this.resourceGroup, this.webAppName);
            var responce =await GetAsync(endpoint);
            _InstanceListTask = GetInstancesFromJson(responce.Content.ReadAsStringAsync().Result);
            this._ListInstance = _InstanceListTask;
            return _InstanceListTask;
        }
        public async Task<List<InstanceDetails>> GetProcess_ForInstance()
        {
            
            string endpoint = string.Empty;
            foreach(var instance in this._ListInstance)
            {
                endpoint = string.Format(ProcesListbyInstanceURL, _appsettings.SubscriptionId, this.resourceGroup, this.webAppName, instance.ARRAffinityId);
                var responce = await GetAsync(endpoint);
                instance.ProcessList = GetProcessListFromJson(responce.Content.ReadAsStringAsync().Result);
            }
            

            return this._ListInstance;
        }
        public async Task<List<InstanceDetails>> GetComputerName_ForInstance_FromProcess()
        {
            string endpoint = string.Empty;
            List<Task> taskList = new List<Task>();
            foreach (var instance in this._ListInstance)
            {
                foreach(var process in instance.ProcessList)
                {
                    endpoint = string.Format(ProcessListbyProcessURL, _appsettings.SubscriptionId, this.resourceGroup, this.webAppName, instance.ARRAffinityId,process.ProcessId);
                    /*
                    var responce = await GetAsync(endpoint);
                    process.ComputerName = GetProcessObjectFromProcessJson(responce.Content.ReadAsStringAsync().Result);
                    */
                    taskList.Add(Processworker(endpoint, process));

                }
                
            }

            await Task.WhenAll(taskList);
            return this._ListInstance;
        }

        public async Task Processworker(string endpoint , Process process)
        {
            var responce = await GetAsync(endpoint);
            process.ComputerName = GetProcessObjectFromProcessJson(responce.Content.ReadAsStringAsync().Result);
        }
        public async Task<HttpResponseMessage> GetAsync(string url)
        {
           // var accessToken = await GetADAccessToken();
            using (var httpClient = new HttpClient())
            {
                httpClient.BaseAddress = new Uri("https://management.azure.com/");
                httpClient.DefaultRequestHeaders.Clear();
                httpClient.DefaultRequestHeaders.Authorization =
                   new System.Net.Http.Headers.AuthenticationHeaderValue
                   (this.accessToken.TokenType, this.accessToken.AccessToken);

                var response = await httpClient.GetAsync(url);
                return response;
            }
        }

        public List<InstanceDetails> GetInstancesFromJson(string Instancejson)
        {
            List<InstanceDetails> _InstanceListTask = new List<InstanceDetails>();
            var JsonObject = Deserilise(Instancejson);
            foreach (var value in JsonObject.value)
            {
                _InstanceListTask.Add(new InstanceDetails()
                {
                    ARRAffinityId = value.name
                });
            }

            return _InstanceListTask;
        }
        public List<Process> GetProcessListFromJson(string Instancejson)
        {
            List<Process> _ProcessList = new List<Process>();

            var JsonObject = Deserilise(Instancejson);
            foreach (var value in JsonObject.value)
            {
                if (value.properties.name.ToLower()== "w3wp")
                {
                    _ProcessList.Add(new Process()
                    {
                        ProcessId = value.properties.id.ToString()
                    });
                }
            }

            return _ProcessList;
        }

        public string GetProcessObjectFromProcessJson(string processJson)
        {
            var JsonObject = Deserilise(processJson);
            string result = string.Empty;
            
                if(!Convert.ToBoolean(JsonObject.properties.is_scm_site))
                {
                    result= JsonObject.properties.environment_variables.COMPUTERNAME.ToString();
                }
                else
                {
                result = "NA";
                }
                
            
            return result;
        }

        public dynamic Deserilise(string json)
        {
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            serializer.RegisterConverters(new[] { new DynamicJsonConverter() });
            
            dynamic obj = serializer.Deserialize(json, typeof(object));

            return obj;
        }
    }
}
